<header>
    <h1>الأنيس للإلكترونيات</h1>
    <nav>
        <a href="index.html">الرئيسية</a> | 
        <a href="dashboard.html">لوحة التاجر</a> | 
        <a href="admin.html">لوحة الإدارة</a>
    </nav>
</header>